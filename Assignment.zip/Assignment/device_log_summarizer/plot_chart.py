"""Section 3: bar chart of average temperature per device.

Usage:
    python plot_chart.py summary.json -o temperature_chart.png [--threshold 80]
"""
import argparse
import json
import sys

import matplotlib
matplotlib.use("Agg")  # headless-safe: write to file, no GUI needed
import matplotlib.pyplot as plt


def load_summary(path):
    with open(path, encoding="utf-8") as f:
        data = json.load(f)
    if not isinstance(data, list) or not data:
        raise ValueError("summary JSON must be a non-empty list of devices.")
    for item in data:
        if "device_id" not in item or "average_temperature" not in item:
            raise ValueError("each entry needs 'device_id' and 'average_temperature'.")
    return data


def plot(data, output, threshold=80.0):
    devices = [d["device_id"] for d in data]
    temps = [d["average_temperature"] for d in data]

    fig, ax = plt.subplots(figsize=(max(6, 0.8 * len(devices) + 3), 5))
    bars = ax.bar(devices, temps, color="#4C78A8", edgecolor="black", linewidth=0.5)

    ax.bar_label(bars, fmt="%.1f", padding=3)           # value labels on bars
    ax.axhline(threshold, color="red", linestyle="--", linewidth=1,
               label=f"Filter threshold ({threshold:g} °C)")
    ax.set_title("Average Temperature per Device", fontsize=14, fontweight="bold")
    ax.set_xlabel("Device ID")
    ax.set_ylabel("Average Temperature (°C)")
    ax.set_ylim(0, max(max(temps), threshold) * 1.15)
    ax.grid(axis="y", linestyle=":", alpha=0.6)
    ax.set_axisbelow(True)
    ax.legend()
    plt.setp(ax.get_xticklabels(), rotation=45, ha="right")  # fix overlapping labels
    fig.tight_layout()
    fig.savefig(output, dpi=150)
    plt.close(fig)


def main(argv=None):
    p = argparse.ArgumentParser(description="Plot average temperature per device.")
    p.add_argument("input", help="JSON file produced by summarizer.py")
    p.add_argument("-o", "--output", default="temperature_chart.png")
    p.add_argument("--threshold", type=float, default=80.0)
    args = p.parse_args(argv)
    try:
        data = load_summary(args.input)
        plot(data, args.output, args.threshold)
    except FileNotFoundError:
        print(f"error: file not found: {args.input}", file=sys.stderr)
        return 1
    except (json.JSONDecodeError, ValueError) as e:
        print(f"error: invalid summary file: {e}", file=sys.stderr)
        return 1
    except OSError as e:
        print(f"error: could not write chart: {e}", file=sys.stderr)
        return 1
    print(f"Saved: {args.output}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
