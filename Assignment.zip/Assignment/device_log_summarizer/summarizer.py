"""Section 2: Device Log Summarizer CLI.

Usage:
    python summarizer.py device_telemetry.csv -o summary.json [--max-avg-temp 80]
"""
import argparse
import csv
import json
import math
import sys
from collections import defaultdict

REQUIRED_COLUMNS = {"device_id", "status", "temperature"}
VALID_STATUSES = {"ACTIVE", "WARNING", "ERROR"}


def read_records(path):
    valid, skipped = [], 0
    with open(path, newline="", encoding="utf-8-sig") as f:
        reader = csv.DictReader(f)
        if reader.fieldnames is None:
            raise ValueError("CSV file is empty.")
        headers = {h.strip() for h in reader.fieldnames if h}
        missing = REQUIRED_COLUMNS - headers
        if missing:
            raise ValueError(f"CSV missing required column(s): {', '.join(sorted(missing))}")

        for line_no, row in enumerate(reader, start=2):
            row = {(k or "").strip(): (v or "").strip() for k, v in row.items()}
            device_id = row["device_id"]
            status = row["status"].upper()
            try:
                temperature = float(row["temperature"])
                if not math.isfinite(temperature):
                    raise ValueError
            except ValueError:
                temperature = None

            if not device_id or status not in VALID_STATUSES or temperature is None:
                skipped += 1
                print(f"warning: skipping line {line_no}: {row}", file=sys.stderr)
                continue
            valid.append({"device_id": device_id, "status": status,
                          "temperature": temperature})
    return valid, skipped


def aggregate(records):
    """Group by device_id -> record count, mean temperature, error count."""
    groups = defaultdict(list)
    for rec in records:
        groups[rec["device_id"]].append(rec)

    results = []
    for device_id in sorted(groups):
        rows = groups[device_id]
        results.append({
            "device_id": device_id,
            "total_records": len(rows),
            "average_temperature": round(sum(r["temperature"] for r in rows) / len(rows), 2),
            "error_count": sum(1 for r in rows if r["status"] == "ERROR"),
        })
    return results


def filter_devices(summaries, max_avg_temp=80.0):
    """Drop devices whose average temperature is above ``max_avg_temp``."""
    return [s for s in summaries if s["average_temperature"] <= max_avg_temp]


def print_table(summaries):
    if not summaries:
        print("No devices to display.")
        return
    header = f"{'Device':<12}{'Records':>9}{'Avg Temp':>11}{'Errors':>9}"
    print(header)
    print("-" * len(header))
    for s in summaries:
        print(f"{s['device_id']:<12}{s['total_records']:>9}"
              f"{s['average_temperature']:>11.2f}{s['error_count']:>9}")


def parse_args(argv=None):
    p = argparse.ArgumentParser(description="Summarize device telemetry CSV.")
    p.add_argument("input", help="Path to device telemetry CSV")
    p.add_argument("-o", "--output", default="summary.json", help="Output JSON path")
    p.add_argument("--max-avg-temp", type=float, default=80.0,
                   help="Exclude devices with average temperature above this (default 80.0)")
    return p.parse_args(argv)


def main(argv=None):
    args = parse_args(argv)
    try:
        records, skipped = read_records(args.input)
    except FileNotFoundError:
        print(f"error: file not found: {args.input}", file=sys.stderr)
        return 1
    except (PermissionError, IsADirectoryError, UnicodeDecodeError, csv.Error, ValueError) as e:
        print(f"error: could not read {args.input}: {e}", file=sys.stderr)
        return 1

    if not records:
        print("error: no valid records found in input.", file=sys.stderr)
        return 1

    summaries = aggregate(records)
    kept = filter_devices(summaries, args.max_avg_temp)
    removed = len(summaries) - len(kept)

    try:
        with open(args.output, "w", encoding="utf-8") as f:
            json.dump(kept, f, indent=2)
    except OSError as e:
        print(f"error: could not write {args.output}: {e}", file=sys.stderr)
        return 1

    print_table(kept)
    print(f"\n{len(records)} valid rows, {skipped} skipped, "
          f"{removed} device(s) filtered (avg temp > {args.max_avg_temp}).")
    print(f"Saved: {args.output}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
