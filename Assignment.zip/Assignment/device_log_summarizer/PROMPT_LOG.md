# PROMPT_LOG.md

## 1. Initial prompt
> Write a Python script that loads `summary.json` (a list of objects with `device_id`,
> `average_temperature`, `total_records`, `error_count`) and generates a bar chart
> comparing average temperature per device using matplotlib. Save it as a PNG.

The draft is kept in `drafts/plot_v1_ai_first_attempt.py`.

## 2. Bugs found in the first attempt
I ran it, including a stress test with 12 long device names (`drafts/v1_output.png`):
- **Overlapping x-axis labels:** long device IDs rendered on top of each other.
- No title, no axis labels, no units, no value labels on bars.
- Used `plt.show()` with no `savefig`, so no PNG is produced (fails on headless machines).
- No error handling for a missing or malformed JSON file.

## 3. Follow-up prompt
> The chart has overlapping x-axis labels when device names are long. Rotate the labels
> 45° and right-align them, call `tight_layout()`, and scale the figure width with the
> number of devices. Also add a title, axis labels with units (°C), value labels on each
> bar, and a dashed line at the 80 °C threshold. Save with `savefig(dpi=150)` using the
> Agg backend instead of `plt.show()`, and handle a missing or invalid JSON file with a
> clear error message and non-zero exit code.

Result: `plot_chart.py`. Verified on the real data (`temperature_chart.png`) and on the
12-device stress test (`drafts/v2_stress.png`).
