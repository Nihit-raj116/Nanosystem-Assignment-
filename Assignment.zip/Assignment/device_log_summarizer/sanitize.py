"""Section 1: clean and normalize sensor readings."""
import math

MAX_READING = 500.0


def clean_sensor_readings(readings, max_value=MAX_READING):
    if readings is None:
        return []
    try:
        iterator = iter(readings)
    except TypeError:
        return []

    cleaned = []
    for raw in iterator:
        if raw is None or isinstance(raw, bool):
            continue
        try:
            value = float(raw)
        except (TypeError, ValueError, OverflowError):
            continue
        if math.isnan(value) or value < 0:
            continue
        cleaned.append(min(value, max_value))
    return cleaned
