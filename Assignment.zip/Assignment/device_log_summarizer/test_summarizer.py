import json
import os
import tempfile
import unittest

import summarizer


def write_csv(text):
    f = tempfile.NamedTemporaryFile("w", suffix=".csv", delete=False)
    f.write(text)
    f.close()
    return f.name


class TestSummarizer(unittest.TestCase):
    def test_aggregate_and_filter(self):
        path = write_csv("device_id,status,temperature\n"
                         "A,ACTIVE,10\nA,ERROR,20\nB,ERROR,90\nB,ERROR,100\n")
        recs, skipped = summarizer.read_records(path)
        summ = summarizer.aggregate(recs)
        self.assertEqual(summ[0], {"device_id": "A", "total_records": 2,
                                   "average_temperature": 15.0, "error_count": 1})
        kept = summarizer.filter_devices(summ, 80.0)
        self.assertEqual([s["device_id"] for s in kept], ["A"])
        self.assertEqual(skipped, 0)
        os.unlink(path)

    def test_bad_rows_skipped(self):
        path = write_csv("device_id,status,temperature\n"
                         "A,ACTIVE,10\nA,ACTIVE,\nA,ACTIVE,xyz\nA,OOPS,5\n,ACTIVE,3\nA,ACTIVE,nan\n")
        recs, skipped = summarizer.read_records(path)
        self.assertEqual(len(recs), 1)
        self.assertEqual(skipped, 5)
        os.unlink(path)

    def test_missing_file_returns_1(self):
        self.assertEqual(summarizer.main(["does_not_exist.csv"]), 1)

    def test_missing_column_and_empty_file(self):
        p1 = write_csv("device_id,status\nA,ACTIVE\n")
        p2 = write_csv("")
        self.assertEqual(summarizer.main([p1]), 1)
        self.assertEqual(summarizer.main([p2]), 1)
        os.unlink(p1); os.unlink(p2)

    def test_end_to_end_json(self):
        path = write_csv("device_id,status,temperature\nA,ACTIVE,50\n")
        out = path + ".json"
        self.assertEqual(summarizer.main([path, "-o", out]), 0)
        with open(out) as f:
            self.assertEqual(json.load(f)[0]["device_id"], "A")
        os.unlink(path); os.unlink(out)


if __name__ == "__main__":
    unittest.main()
