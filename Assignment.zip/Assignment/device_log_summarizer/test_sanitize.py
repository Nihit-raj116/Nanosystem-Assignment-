import unittest
from sanitize import clean_sensor_readings


class TestCleanSensorReadings(unittest.TestCase):
    def test_mixed_input(self):
        data = [10, "25.5", None, -3, "abc", 600, "700.1", 0, " 42 "]
        self.assertEqual(clean_sensor_readings(data),
                         [10.0, 25.5, 500.0, 500.0, 0.0, 42.0])

    def test_empty_and_none(self):
        self.assertEqual(clean_sensor_readings([]), [])
        self.assertEqual(clean_sensor_readings(None), [])
        self.assertEqual(clean_sensor_readings(123), [])  # non-iterable

    def test_all_invalid(self):
        self.assertEqual(
            clean_sensor_readings([None, "x", -1, "-5", float("nan"), True, [], {}]),
            [])

    def test_boundaries(self):
        self.assertEqual(clean_sensor_readings([500, 500.0001, "0", -0.0001]),
                         [500.0, 500.0, 0.0])


if __name__ == "__main__":
    unittest.main()
